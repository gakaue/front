import React, { useEffect, useState } from "react";
import "../styles/Perfil.css";
import userIcon from "../assets/img/user-icon.png";
import api from "../service/api";
import petsImage from "../assets/img/gatodeitado.webp";
import Navbar from "../components/Navbar"; // mantém o mesmo Navbar global

const Perfil: React.FC = () => {
  const [userData, setUserData] = useState<{ nome: string; email: string } | null>(null);

  useEffect(() => {
    // Simula busca de dados do usuário logado
    const storedUser = localStorage.getItem("pp_user");
    if (storedUser) {
      setUserData(JSON.parse(storedUser));
    } else {
      // Dados padrão caso não tenha nada salvo
      setUserData({ nome: "Usuário PetPalace", email: "usuario@petpalace.com" });
    }
  }, []);

  const handleEdit = () => {
    alert("Função de edição em desenvolvimento 🐾");
  };

  return (
    <div className="perfil-page">
      <div className="perfil-container">
        <div className="perfil-header">
          <img src={userIcon} alt="Usuário" className="perfil-foto" />
          <div>
            <h2>{userData?.nome}</h2>
            <p>{userData?.email}</p>
          </div>
        </div>

        <div className="perfil-card">
          <h3>Informações da Conta</h3>
          <p><strong>Nome:</strong> {userData?.nome}</p>
          <p><strong>E-mail:</strong> {userData?.email}</p>
          <button className="editar-btn" onClick={handleEdit}>
            Editar Perfil
          </button>
        </div>

        <div className="perfil-card">
          <h3>Minhas Reservas</h3>
          <p>Você ainda não possui reservas ativas.</p>
        </div>

        <div className="perfil-card">
          <h3>Preferências</h3>
          <p>Personalize suas notificações e preferências de hospedagem.</p>
        </div>
      </div>
    </div>
  );
};

export default Perfil;
