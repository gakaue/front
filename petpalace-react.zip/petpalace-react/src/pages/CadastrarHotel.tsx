import React, { useState } from "react";
import Navbar from "../components/Navbar";
import "../styles/CadastrarHotel.css";

const CadastrarHotel: React.FC = () => {
  const [formData, setFormData] = useState({
    nomeHotel: "",
    endereco: "",
    cidade: "",
    estado: "",
    telefone: "",
    email: "",
    descricao: "",
    preco: "",
    imagemUrl: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Hotel cadastrado com sucesso!");
  };

  return (
    <>
      <Navbar />

      <div className="cadastrarhotel-page">
        <section className="cadastrarhotel-section">
          <div className="cadastrarhotel-form-container">
            <h1>Cadastrar Hotel</h1>
            <p>Preencha os dados abaixo para cadastrar seu hotel</p>

            <form onSubmit={handleSubmit} className="cadastrarhotel-form">
              <div className="cadastrarhotel-form-grid">
                <input
                  type="text"
                  name="nomeHotel"
                  placeholder="Nome do Hotel"
                  value={formData.nomeHotel}
                  onChange={handleChange}
                  required
                />
                <input
                  type="text"
                  name="endereco"
                  placeholder="Endereço"
                  value={formData.endereco}
                  onChange={handleChange}
                  required
                />
                <input
                  type="text"
                  name="cidade"
                  placeholder="Cidade"
                  value={formData.cidade}
                  onChange={handleChange}
                  required
                />
                <input
                  type="text"
                  name="estado"
                  placeholder="Estado"
                  value={formData.estado}
                  onChange={handleChange}
                  required
                />
                <input
                  type="text"
                  name="telefone"
                  placeholder="Telefone"
                  value={formData.telefone}
                  onChange={handleChange}
                  required
                />
                <input
                  type="email"
                  name="email"
                  placeholder="E-mail"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
                <input
                  type="text"
                  name="descricao"
                  placeholder="Descrição"
                  value={formData.descricao}
                  onChange={handleChange}
                />
                <input
                  type="number"
                  name="preco"
                  placeholder="Preço por diária (R$)"
                  value={formData.preco}
                  onChange={handleChange}
                />
                <input
                  type="text"
                  name="imagemUrl"
                  placeholder="URL da imagem"
                  value={formData.imagemUrl}
                  onChange={handleChange}
                />
              </div>

              {formData.imagemUrl && (
                <div className="cadastrarhotel-image-preview">
                  <img src={formData.imagemUrl} alt="Prévia do hotel" />
                </div>
              )}

              <button type="submit" className="cadastrarhotel-btn-cadastrar">
                Cadastrar
              </button>
            </form>
          </div>
        </section>
      </div>
    </>
  );
};

export default CadastrarHotel;
