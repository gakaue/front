import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import Servicos from "./pages/Servicos";
import Contato from "./pages/Contato";
import Reservar from "./pages/Reservar";
import Login from "./pages/Login";
import Cadastrar from "./pages/Cadastrar";
import CadastrarHotel from "./pages/CadastrarHotel";
import Perfil from "./pages/Perfil"; // 👈 nova importação

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/servicos" element={<Servicos />} />
        <Route path="/contato" element={<Contato />} />
        <Route path="/reservar" element={<Reservar />} />
        <Route path="/login" element={<Login />} />
        <Route path="/cadastrar" element={<Cadastrar />} />
        <Route path="/cadastrarhotel" element={<CadastrarHotel />} />
        <Route path="/perfil" element={<Perfil />} /> {/* 👈 nova rota */}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
